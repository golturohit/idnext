const TopRoundInco = () => {
  return (
    <>
      <svg
        className="line-dash-path"
        width="38"
        height="122"
        viewBox="0 0 38 122"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M0.279297 1C41.9846 20.0005 55.1988 87.9525 2.74393 121.294"
          stroke="#A7ACB3"
          strokeDasharray="4 4"
        />
      </svg>
    </>
  );
};

export default TopRoundInco;
