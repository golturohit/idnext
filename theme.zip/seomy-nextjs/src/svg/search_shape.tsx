const SearchShape = () => {
  return (
    <>
      <svg
        width="406"
        height="40"
        viewBox="0 0 406 40"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M3.14977 24.4029C3.14977 24.4029 256.329 -7.75032 398.26 15.5002"
          stroke="#FFCE5A"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <path
          d="M3.59029 19.0626C3.59029 19.0626 261.471 -1.12129 402.878 28.422"
          stroke="#FFCE5A"
          strokeWidth="5"
          strokeLinecap="round"
        />
      </svg>
    </>
  );
};

export default SearchShape;
